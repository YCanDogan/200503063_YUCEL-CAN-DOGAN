public class Kunde {
}
