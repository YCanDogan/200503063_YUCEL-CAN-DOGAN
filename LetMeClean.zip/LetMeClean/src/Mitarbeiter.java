public class Mitarbeiter {
}
